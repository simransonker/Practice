<html>
<head>

</head>
<body>
    <form action="progcode1.php" method="post">
        Name<input type="text" name="name">
        FatherName<input type="text" name="Fname">
        MotherName<input type="text" name="Mname">
        Email<input type="email" name="email">
        Password<input type="password" name="pass">
        <button>Save</button>
    </form>
</body>

    </html>