<html>
    <head>

    </head>
    <body>
        <h1>OTP Page</h1>

        <form action="otpcode.php" method="post">
            Enter your OTP <input type="number" name="otp"><br>
            <button>Send</button>
        </form>
    </body>
</html>