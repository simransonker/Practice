name
father name
mother name
email id`
password
