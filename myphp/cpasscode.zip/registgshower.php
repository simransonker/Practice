<?php
 $conn=mysqli_connect("localhost","root","","phpdb");
 $sel="select * from   "
?>