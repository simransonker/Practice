<html>
    <head>

    </head>
    <body>
        <h1>Change Password page</h1>
        <form action="cpasscode.php" method="post">
            New password <input type="text" name="npass">
             <br>
            Confirm password <input type="text" name="cpass">
            <br>
            <button>change Password</button>
        </form>
    </body>
</html>