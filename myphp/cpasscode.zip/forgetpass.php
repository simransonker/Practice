<html>
    <head>

    </head>
    <body>
        <h1>Forget Password Page</h1>
        <form action=" forgetpasscode.php" method="post">
       Enter Email <input type="email" name="email"><br>
       <button>Submit</button>
        </form>
    </body>
</html>