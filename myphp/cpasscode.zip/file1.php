<html>
    <head>
</head>
<body>
<h1>File Uplode Page</h1>
    <form action="filecode.php" method="post" enctype="multipart/form-data">
        picture<input type="file" name="img"><br>
        <button>Uplode</button>
       
        

</form>

    <body>
    </html>