<?php
   $name=$_POST['name'];
   $gender=$_POST['gend'];
   $hobby=implode(' , ',$_POST['hobby']);
   $city=$_POST['city'];
   $add=$_POST['add'];
  
$conn=mysqli_connect("localhost","root","","phpdb");
if(!$conn)
{
    echo("Something went wrong!");

}
else
{
    $insert = "insert into regtbl(name,gender,hobby,city,address) values('$name','$gender','$hobby','$city','$add')";

    if(mysqli_query($conn,$insert))
    {
    echo("<script>window.locahost.href='register.php'; alert('Data Insert!')</script>");
        // echo("data is  insert");
    }
    else
        
    {
        echo("data is not insert");
    }
}

?>