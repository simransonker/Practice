<html>
    <head>

    </head>
    <body>
        <h1>Registration page</h1>
        <form action="registrationpgcode.php" method="post">
            Name <input type="text" name="name">
            <br>
            Email <input type="email" name="email"><br>
            Password <input type="text" name="pass"><br>
            mobile <input type="number" name="num"><br>
            <button>next</button>
        </form>
    </body>
</html>