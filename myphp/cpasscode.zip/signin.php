<html>
    <head>
</head>
<h1>Signin Page</h1>
<form action="signincode.php" method="post" enctype="multipart/form-data">
    email <input type="email" name="email">
    password <input type="text" name="pass">

    <button>Signin</button><a href="forgetpass.php">Forget Password?</a>

</form>
    </html>