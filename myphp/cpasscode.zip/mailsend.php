<html>
    <head>

    </head>
    <body>
        <h1>Mail Page</h1>
        <form action="mailcode.php" method="post">
            To-Email <input type="email" name="toemail"></br>
            Subject <input type="text" name="subject"><br>
            Message <textarea name="msg" ></textarea><br>
           <button>Send</button>
        </form>
    </body>
</html>